<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kecamatan extends CI_Controller {

	function __construct()
    {
        parent:: __construct();

        $this->load->model('M_kecamatan');
        $this->load->model('M_kabupaten');
        
    }

	public function index()
	{

        $data['title']="Manajemen Data Kecamatan";
        $data['kecamatan']=$this->M_kecamatan->tampil_data()->result_array();

        $this->load->view('v_header', $data);
		$this->load->view('kecamatan/v_data', $data);
        $this->load->view('v_footer');
	}

    function tambah(){
    $data['title']="Tambah Data Kecamatan";

    $data['kabupaten']=$this->M_kabupaten->tampil_data()->result_array();
        
    $this->load->view('v_header', $data);
	$this->load->view('kecamatan/v_data_tambah', $data);
    $this->load->view('v_footer');
	}

        function insert(){

        $kecamatan=$this->input->post('kecamatan');
        $kabupaten=$this->input->post('kabupaten');
        

        $data=array(
            
            'namaKecamatan'=>$kecamatan,
            'idKabupaten'=>$kabupaten

        );

        $this->M_kecamatan->insert_data($data);

        redirect('kecamatan');
    }




   

    function edit($id){
        $data['title']="Edit Data Kecamatan";
        

        $where=array('idKecamatan'=>$id);
        $data['edit']=$this->M_kecamatan->edit_data($where)->row_array();

        $data['kabupaten']=$this->M_kabupaten->tampil_data()->result_array();

       

        $this->load->view('v_header', $data);
        $this->load->view('kecamatan/v_data_edit', $data);
        $this->load->view('v_footer');
    }


       function update(){
        $id=$this->input->post('idKecamatan');
        $kecamatan=$this->input->post('Kecamatan');
        $kabupaten=$this->input->post('idKabupaten');
        
        

        $data=array(
            'idKecamatan'=>$id,
            'namaKecamatan'=>$kecamatan,
            'idKabupaten'=>$kabupaten

        );

        $where=array('idKecamatan'=>$id);
        $this->M_kecamatan->update_data($data,$where);

        redirect('kecamatan');
    }
   

    // function hapus($id){
    //     $where=array('idDokter'=>$id);
    //     $this->M_dokter->hapus_data($where);

    //     redirect('dokter');
    // }
}
