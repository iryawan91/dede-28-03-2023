<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siswa extends CI_Controller {

	function __construct()
    {
        parent:: __construct();

        $this->load->model('M_siswa');
        $this->load->model('M_kecamatan');
        $this->load->model('M_kabupaten');
        
    }

	public function index()
	{

        $data['title']="Manajemen Data Siswa";
        $data['siswa']=$this->M_siswa->tampil_data()->result_array();

        $this->load->view('v_header', $data);
        $this->load->view('siswa/v_data', $data);
        $this->load->view('v_footer');
    
	}

     function tambah(){
    $data['title']="Tambah Data siswa";

    $data['kecamatan']=$this->M_kecamatan->tampil_data()->result_array();
    $data['kabupaten']=$this->M_kabupaten->tampil_data()->result_array();
        
    $this->load->view('v_header', $data);
    $this->load->view('siswa/v_data_tambah', $data);
    $this->load->view('v_footer');
    }


     function insert(){
        $siswa=$this->input->post('siswa');
        $kecamatan=$this->input->post('kecamatan');
        $kabupaten=$this->input->post('kabupaten');
        $alamat=$this->input->post('alamat');

        $data=array(

            'namaSiswa'=>$siswa,
            'idKabupaten'=>$kabupaten,
            'idKecamatan'=>$kecamatan,
            'alamatSiswa'=>$alamat,

        );

        $this->M_siswa->insert_data($data);

        redirect('siswa');
    }



    // function edit($id){
    //     $data['title']="Edit Data Dokter";

    //     $where=array('idDokter'=>$id);
    //     $data['r']=$this->M_dokter->edit_data($where)->row_array();

    //     $this->load->view('v_header', $data);
	// 	$this->load->view('dokter/v_data_edit', $data);
    //     $this->load->view('v_footer');
	// }

    // function update(){
    //     $id=$this->input->post('idDokter');      
    //     $n=$this->input->post('namaDokter');

    //     $data=array(
    //         'namaDokter'=>$n,
    //     );

    //     $where=array('idDokter'=>$id);
    //     $this->M_dokter->update_data($data,$where);

    //     redirect('dokter');
	// }
    

    // function hapus($id){
    //     $where=array('idDokter'=>$id);
    //     $this->M_dokter->hapus_data($where);

    //     redirect('dokter');
    // }
}
