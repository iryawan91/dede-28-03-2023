<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kabupaten extends CI_Controller {

	function __construct()
    {
        parent:: __construct();

        $this->load->model('M_kabupaten');
        
    }

	public function index()
	{

        $data['title']="Manajemen Data Kabupaten";
        $data['kabupaten']=$this->M_kabupaten->tampil_data()->result_array();

        $this->load->view('v_header', $data);
		$this->load->view('kabupaten/v_data', $data);
        $this->load->view('v_footer');
	}

    function tambah(){
     $data['title']="Tambah Data Kabupaten";
        
      $this->load->view('v_header', $data);
		$this->load->view('kabupaten/v_data_tambah', $data);
         $this->load->view('v_footer');
	 }

    function insert(){
     $n=$this->input->post('namaKabupaten');

         $data=array(
         'namaKabupaten'=>$n

         );

         $this->M_kabupaten->insert_data($data);

         redirect('kabupaten');
	}



    function edit($id){
         $data['title']="Edit Data Kabupaten";

         $where=array('idKabupaten'=>$id);
        $data['r']=$this->M_kabupaten->edit_data($where)->row_array();

        $this->load->view('v_header', $data);
	       $this->load->view('kabupaten/v_data_edit', $data);
         $this->load->view('v_footer');
	}

    function update(){
         $id=$this->input->post('idKabupaten');      
         $n=$this->input->post('namaKabupaten');

         $data=array(
             'namaKabupaten'=>$n,
         );

         $where=array('idKabupaten'=>$id);
        $this->M_kabupaten->update_data($data,$where);

         redirect('kabupaten');
	 }
    

     function hapus($id){
         $where=array('idKabupaten'=>$id);
         $this->M_kabupaten->hapus_data($where);

         redirect('kabupaten');
     }
}
