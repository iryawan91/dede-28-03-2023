

<section class="konten mt-2">
        <div class="card text-white  mx-3">
            <div class="card-header bg-primary ">
                <?= $title; ?>
                <a href="<?= base_url('siswa'); ?>" class="btn btn-warning btn-sm float-right"> Kembali</a>
            </div>
            <div class="card-body text-dark">
                <form method="post" action="<?= base_url('siswa/update'); ?>" >
                <input type="hidden"  name="idSiswa" value="<?= $edit['idSiswa']; ?>">    
                  
                    <div class="form-group">
                        <label>Nama Siswa</label>
                        <input type="text" class="form-control" name="siswa" value="<?= $edit['namasiswa']; ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Nama Kabupaten</label>
                        <select name="idkabupaten" class="form-control">
                            <option value="">-Pilih Kabupaten-</option>
                            <?php foreach($kabupaten as $kb) { ?>
                            <option value="<?=  $kb['idKabupaten']; ?>"><?=  $kb['namaKabupaten']; ?></option>
                            <?php } ?>
                        </select>
                    </div>


                    <div class="form-group">
                        <label>Nama Kecamatan</label>
                        <select name="idkabupaten" class="form-control">
                            <option value="">-Pilih Kecamatan-</option>
                            <?php foreach($kecamatan as $kc) { ?>
                            <option value="<?=  $kc['idKecamatan']; ?>"><?=  $k['namaKecamatan']; ?></option>
                            <?php } ?>
                        </select>
                    </div>



                    <div class="form-group">
                        <label>Alamat Siswa</label>
                        <input type="text" class="form-control" name="siswa" value="<?= $edit['alamatSiswa']; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Update Data</button>
                    </div>
                </form>
            </div>
        </div>
</section>