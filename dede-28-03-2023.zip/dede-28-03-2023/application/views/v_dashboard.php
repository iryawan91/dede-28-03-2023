<section class="content">
    <div class="container-fluid mt-4">
        <div class="jumbotron">
        <h1>Selamat Datang di Aplikasi Data Siswa</h1>
        <hr class="my-4">
        </div>
    </div>
</section>
