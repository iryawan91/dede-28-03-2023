

<section class="konten mt-2">
        <div class="card text-white  mx-3">
            <div class="card-header bg-primary ">
                <?= $title; ?>
                <a href="<?= base_url('kecamatan'); ?>" class="btn btn-warning btn-sm float-right"> Kembali</a>
            </div>
            <div class="card-body text-dark">
                <form method="post" action="<?= base_url('kecamatan/update'); ?>" >
                <input type="hidden"  name="idKecamatan" value="<?= $edit['idKecamatan']; ?>">    
                  
                    <div class="form-group">
                        <label>Nama Kecamatan</label>
                        <input type="text" class="form-control" name="kecamatan" value="<?= $edit['namaKecamatan']; ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Nama Kabupaten</label>
                        <select name="idkabupaten" class="form-control">
                            <option value="">-Pilih Kabupaten-</option>
                            <?php foreach($kabupaten as $k) { ?>
                            <option value="<?=  $k['idKabupaten']; ?>"><?=  $k['namaKabupaten']; ?></option>
                            <?php } ?>
                        </select>
                    </div>


                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Update Data</button>
                    </div>
                </form>
            </div>
        </div>
</section>