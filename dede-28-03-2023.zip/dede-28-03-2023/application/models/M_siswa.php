<?php

class M_siswa extends CI_Model{

    function tampil_data(){
        //return $this->db->get('siswa');
        $query=$this->db->query("SELECT siswa.idSiswa, siswa.namaSiswa, kabupaten.namaKabupaten, kecamatan.namaKecamatan, siswa.alamatSiswa
            FROM siswa
            JOIN kecamatan ON siswa.idKecamatan = kecamatan.idKecamatan
            JOIN kabupaten ON kecamatan.idKabupaten = kabupaten.idKabupaten;

        ");
        return $query;

    }

    function insert_data($data){
    return $this->db->insert('siswa',$data);

    }


    // function edit_data($where){
    //     return $this->db->get_where('dokter',$where);
    // }

    // function update_data($data, $where){
    //     $this->db->where($where);
    //     $this->db->update('dokter',$data);
    // }

    // function hapus_data($where){
    //     $this->db->where($where);
    //     $this->db->delete('dokter');
    
    // }
}