<?php

class M_kecamatan extends CI_Model{

    function tampil_data(){
       // return $this->db->get('kecamatan');
        $query=$this->db->query("SELECT kecamatan.idKecamatan, kecamatan.namaKecamatan, kabupaten.namaKabupaten FROM kecamatan JOIN kabupaten ON kecamatan.idKabupaten = kabupaten.idKabupaten;
        ");
        return $query;

        
    }

    function insert_data($data){
    return $this->db->insert('kecamatan',$data);

    }

    function edit_data($where){
        return $this->db->get_where('kecamatan',$where);
    }


        function update_data($data, $where){
        $this->db->where($where);
        $this->db->update('kecamatan',$data);
    }

    // function hapus_data($where){
    //     $this->db->where($where);
    //     $this->db->delete('dokter');
    
    // }
}